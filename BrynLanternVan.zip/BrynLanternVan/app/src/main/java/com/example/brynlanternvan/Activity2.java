package com.example.brynlanternvan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity2 extends AppCompatActivity {
    Button pickedUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        pickedUp = (Button)findViewById(R.id.pickedUp);
        pickedUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCurrentRide();
            }
        });
    } // onCreate()

    public void openCurrentRide() {
        Intent intent = new Intent(this, Current_ride.class);
        startActivity(intent);
    } // openCurrentRide()
} // Activity2